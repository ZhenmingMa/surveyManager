package com.cby.repository;

import com.cby.entity.AnswerDemand;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Ma on 2017/6/13.
 */
public interface AnswerDemandRepo extends JpaRepository<AnswerDemand,Integer> {
}
